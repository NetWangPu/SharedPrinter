package com.shared.printer.management.MQTT;

import lombok.Data;

@Data
public class Device {
    String id;
    String State;
}
