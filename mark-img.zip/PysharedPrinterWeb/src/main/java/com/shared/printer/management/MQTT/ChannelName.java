package com.shared.printer.management.MQTT;

public class ChannelName {


    /**
     * 入站管道
     */
    public final static String INPUT_DATA="input_data";
    /**
     * TCP出站管道
     */
    public final static String OUTPUT_DATA_TCP="output_data_TCP";

    /**
     * mqtt出站管道名称
     */
    public final static String OUTPUT_DATA_MQTT="output_data_MQTT";

}
