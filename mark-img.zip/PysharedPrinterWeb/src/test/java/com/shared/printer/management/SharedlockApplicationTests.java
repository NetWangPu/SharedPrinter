package com.shared.printer.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharedlockApplicationTests {

    @Test
    void contextLoads() {
    }

}
